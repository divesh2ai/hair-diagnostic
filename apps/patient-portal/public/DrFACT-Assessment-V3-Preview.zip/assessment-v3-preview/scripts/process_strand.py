#!/usr/bin/env python3
"""Extract the generated strand from its magenta key and build aligned states."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from PIL import Image, ImageEnhance


def extract_strand(source: Path) -> Image.Image:
    image = Image.open(source).convert("RGB")
    pixels = np.asarray(image).astype(np.float32)
    red, green, blue = pixels[..., 0], pixels[..., 1], pixels[..., 2]

    # The generated key includes a soft magenta cast shadow. Hue separation is
    # more reliable than a flood fill and keeps the brown fibre texture intact.
    magenta_score = np.minimum(red - green, blue - green)
    alpha = np.clip((8.0 - magenta_score) / 16.0, 0.0, 1.0) * 255.0

    rgba = np.dstack([pixels, alpha]).astype(np.uint8)
    extracted = Image.fromarray(rgba, "RGBA")
    bbox = extracted.getbbox()
    if not bbox:
        raise RuntimeError("No strand pixels remained after key extraction")
    return extracted.crop(bbox)


def tint(image: Image.Image, dark: str, light: str, opacity: float) -> Image.Image:
    gray = ImageEnhance.Contrast(image.convert("L")).enhance(1.08)
    dark_rgb = tuple(int(dark[i : i + 2], 16) for i in (0, 2, 4))
    light_rgb = tuple(int(light[i : i + 2], 16) for i in (0, 2, 4))
    tinted = Image.merge(
        "RGB",
        tuple(
            gray.point(lambda value, d=d, l=l: int(d + (l - d) * value / 255))
            for d, l in zip(dark_rgb, light_rgb)
        ),
    )
    alpha = image.getchannel("A").point(lambda value: int(value * opacity))
    tinted.putalpha(alpha)
    return tinted


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    master = extract_strand(args.source).resize((2160, 154), Image.Resampling.LANCZOS)

    states = {
        "hair-progress-base.webp": tint(master, "3d3429", "a79573", 0.62),
        "hair-progress-active.webp": tint(master, "725a2d", "f5dfa5", 0.98),
    }
    for filename, image in states.items():
        image.save(args.output_dir / filename, "WEBP", lossless=True, method=6)


if __name__ == "__main__":
    main()
