# Dr. FACT Assessment V3 — Isolated Preview

This package is visually and operationally self-contained. It does not import or modify the production questionnaire.

## Preview

Serve this folder with any static server, then open `index.html`:

```bash
python -m http.server 4173 --directory assessment-v3-preview
```

The preview supports three URL states:

- `?view=desktop`
- `?view=mobile`
- `?view=chapter`

Option selection and the Continue button are interactive. Continue advances the strand from 59% to 72% without layout movement.

## Assets

- `public/design-preview/assessment-v3/strand/` — pixel-aligned base and active strand WebP files, 2160×154
- `public/design-preview/assessment-v3/chapters/` — desktop and mobile Nutrition art in AVIF and WebP, at 1× and 2×

`scripts/process_strand.py` reproducibly creates both progress states from one generated master image so their geometry cannot drift.

## Production integration

Move `public/design-preview/assessment-v3` into the patient portal's `public` directory, then port the scoped HTML/CSS into `app/design-preview/assessment-v3`. The palette and selectors are isolated from the current indigo questionnaire styles.
