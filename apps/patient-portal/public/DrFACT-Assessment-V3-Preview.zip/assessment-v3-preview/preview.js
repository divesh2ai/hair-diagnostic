const studio = document.querySelector(".preview-studio");
const viewButtons = [...document.querySelectorAll("[data-view-button]")];

const setView = (view) => {
  studio.dataset.view = view;
  viewButtons.forEach((button) => {
    button.classList.toggle("is-active", button.dataset.viewButton === view);
  });
  const url = new URL(window.location.href);
  url.searchParams.set("view", view);
  history.replaceState({}, "", url);
};

viewButtons.forEach((button) => {
  button.addEventListener("click", () => setView(button.dataset.viewButton));
});

document.querySelectorAll(".option-grid").forEach((grid) => {
  grid.addEventListener("click", (event) => {
    const card = event.target.closest(".option-card");
    if (!card) return;
    grid.querySelectorAll(".option-card").forEach((option) => {
      const selected = option === card;
      option.classList.toggle("is-selected", selected);
      option.setAttribute("aria-checked", String(selected));
    });
  });
});

document.querySelectorAll("[data-next-question]").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll("[data-progress-root]").forEach((root) => {
      root.style.setProperty("--progress", "72%");
      root.querySelector("[role=progressbar]").setAttribute("aria-valuenow", "72");
      const label = root.querySelector("[data-progress-label]");
      label.textContent = label.textContent.includes("Question")
        ? "Question 6 of 7 · 72%"
        : "6 of 7 · 72%";
    });
  });
});

const requestedView = new URLSearchParams(window.location.search).get("view");
if (["desktop", "mobile", "chapter"].includes(requestedView)) setView(requestedView);
