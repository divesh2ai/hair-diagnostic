# Asset generation prompts

The three directions below were generated with the built-in image generation workflow, then converted locally into the production files in `public/design-preview/assessment-v3`.

## Hair-strand master

Use case: stylized-concept  
Asset type: decorative progress indicator master for a premium mobile-first hair-health assessment  
Primary request: Create one elegant, continuous human hair fibre running horizontally from far left to far right, with a subtle organic wave and a refined microscopic surface texture. The fibre should feel premium and believable, not like rope, wire, ribbon, or a tree branch.  
Scene/backdrop: perfectly flat solid #ff00ff chroma-key background for later removal; one uniform color, no gradients, texture, shadows, reflections, floor plane, or lighting variation.  
Style/medium: high-end macro editorial realism with subtle scientific beauty imagery  
Composition/framing: extremely wide horizontal composition; the single fibre occupies the middle horizontal band, no cropped ends, generous clean space above and below, visual weight consistent across the full width  
Lighting/mood: soft controlled studio sheen on the hair, quiet and sophisticated  
Color palette: neutral charcoal-brown hair with warm champagne highlights; do not use magenta anywhere in the fibre  
Constraints: exactly one continuous fibre; no scalp, face, hands, follicles, roots, typography, symbols, logo, watermark, cast shadow, contact shadow, or glow outside the fibre; crisp separable silhouette; background must remain perfectly uniform #ff00ff

## Nutrition — desktop

Use case: ads-marketing  
Asset type: full-bleed desktop chapter transition artwork for a premium hair-health assessment  
Primary request: An immersive editorial still life representing nutrition as the foundation of healthy hair: a dark ceramic bowl with amla, pomegranate, almonds, pumpkin seeds, leafy greens, and a small linen fold, arranged with restraint on a deep forest-green stone surface. The scene should feel sophisticated, sensory, and modern—not a clinical leaflet and not a food advertisement.  
Style/medium: photorealistic luxury wellness editorial photography, natural textures, subtle depth, cinematic but believable  
Composition/framing: wide 16:10 landscape composition; ingredients concentrated primarily on the right half and lower-right quadrant; preserve generous calm negative space across the left 42% and upper-left for cream chapter typography; no important object at crop edges  
Lighting/mood: low-key directional dawn light, warm champagne-gold highlights, soft forest shadows, quiet restorative mood  
Color palette: deep forest green, warm cream, muted botanical reds, champagne gold; controlled saturation  
Constraints: no people, hair, scalp, medicine, supplement bottles, packaging, utensils with branding, typography, logo, watermark, diagram, or floating ingredients; premium photographic realism; clean title-safe negative space

## Nutrition — mobile

Use case: ads-marketing  
Asset type: full-bleed mobile chapter transition artwork for a premium hair-health assessment  
Primary request: A portrait-oriented companion image to a luxury nutrition still life: a dark ceramic bowl with amla, pomegranate, almonds, pumpkin seeds, and leafy greens on a deep forest-green stone surface, with a restrained linen fold. It should represent nourishment as the foundation of healthy hair, with an immersive premium editorial mood.  
Style/medium: photorealistic luxury wellness editorial photography, natural textures, refined and believable  
Composition/framing: very tall 9:19.5 portrait composition; the bowl and ingredients sit entirely in the lower 38% of frame; preserve the upper 52% as calm dark forest negative space for centered cream chapter typography; one subtle botanical branch may enter from the upper-right edge but must not obstruct the title area; mobile-safe crop  
Lighting/mood: low-key directional dawn light from upper left, warm champagne-gold highlights, soft deep shadows, restorative and intimate  
Color palette: deep forest green, warm cream, muted botanical red, champagne gold; controlled saturation  
Constraints: no people, hair, scalp, medicine, supplement bottles, packaging, typography, logo, watermark, diagram, floating ingredients, or branded object; no important object at frame edges; premium photographic realism and clear title-safe negative space
