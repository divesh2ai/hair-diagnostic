# 04 — Recommendation Engine

## Executive Summary
HairOS recommendation is **deterministic and auditable**. Patient answers fire kit rules (Q1–Q13 → kit set); hard rules filter by gender / diet / age; governance overrides resolve known conflicts (G-1..G-4); deduplication produces the candidate set; phase sequencing places each surviving kit into one of four phases (Terrain → Primary → Systemic → Consolidate) using root-cause precedence. The full ruleset is canonical in [`../CONDITION_KIT_MAPPING_REFERENCE.md`](../CONDITION_KIT_MAPPING_REFERENCE.md) (v2, 2026-06-08 governance locked); the reasoning constitution is [`../HAIROS_RECOMMENDATION_DECISION_ENGINE_CONSTITUTION.md`](../HAIROS_RECOMMENDATION_DECISION_ENGINE_CONSTITUTION.md). This file gives the architectural overview and code-to-spec map.

## 1. Canonical Reasoning Chain
Per RDE Constitution §7:
```
Root Cause → Clinical Objective → Capability → Intervention Class
            → Recommendation Candidate → Kit Eligibility → Recommendation
```
No layer may be skipped or inverted. Causes are inputs; the RDE does not adjudicate cause selection.

## 2. Pipeline (code-anchored)

```
patient answers
      │
      ▼  deriveSignals               src/packages/ai-engine/clinical-engine/deriveSignals.ts
   signals (canonical)               src/packages/ai-engine/clinical-engine/signals.ts
      │
      ▼  scoreConditions             src/packages/ai-engine/clinical-engine/scoreConditions.ts
   ranked diagnoses (DiagnosisKey)   src/packages/ai-engine/clinical-engine/types.ts
      │
      ▼  cause-registry              src/packages/ai-engine/cause-registry/engine.ts
   ranked root causes (10 causes,    catalog.ts (Bayesian softmax)
   composite rules)
      │
      ▼  evaluateClinicalProfile     src/packages/ai-engine/clinical-engine/evaluateClinicalProfile.ts
   ClinicalProfile { primary, secondary, severity, drivers, gradeBand, ... }
      │
      ▼  scoreKits + rules           src/packages/ai-engine/kit-scorer/scoreKits.ts
   candidate kits                    + 16 rules in kit-scorer/rules/
      │
      ▼  applyHardRules              kit-scorer/rules/* + ranking/kitCapCalculator.ts
   filtered by gender / diet / age   (HR-1..HR-6)
      │
      ▼  applyGovernance             G-1..G-4 (encoded in rules/)
   override-resolved candidates
      │
      ▼  dedupe + kitPrioritizer     kit-scorer/ranking/kitPrioritizer.ts
   ordered candidate set
      │
      ▼  protocolSequencer           kit-scorer/protocolSequencer.ts
   PROTOCOL_SEQUENCER[DiagnosisKey] → base phase ordering
      │
      ▼  buildProtocol               clinical-engine/buildProtocol.ts
   final 4-phase protocol            (Phase 1 terrain → Phase 4 consolidate)
      │
      ▼  buildTopicals               clinical-engine/buildTopicals.ts
   topical add-ons
      │
      ▼  resolveKit                  kit-scorer/resolveKit.ts
   final patient kit recommendation
```

## 3. Hard Rules (always applied at finalization)
Per [`../CONDITION_KIT_MAPPING_REFERENCE.md`](../CONDITION_KIT_MAPPING_REFERENCE.md) §3:

| ID | Rule | Effect |
|---|---|---|
| HR-1 | Q12 (diet) = Veg/Vegan/Jain | Globally swap every kit to its VEG variant if one exists |
| HR-2 | Q9 (hormonal) = Pregnancy | HEALTHY-9 is the **only** kit; all other rules suppressed |
| HR-3 | Gender = Male | Drop FPHL, F-PCOS-1, FH WELL 3, HEALTHY-9, LACTIHEALTH, peri/post-menopause kits |
| HR-4 | Gender = Female | Drop MPHL |
| HR-5 | Age > 30 with MPHL/FPHL candidate | +1 severity score on MPHL/FPHL |
| HR-6 | Dedup | Same kit triggered multiple times → keep once |

## 4. Governance Overrides (locked 2026-06-08)
These override the Sequencer xlsx where they disagree:

| ID | Rule | Resolution |
|---|---|---|
| G-1 | Post-partum (not feeding) | PRO FACT META B + PRO IMMUNE GOLD (Mapping wins over Sequencer) |
| G-2 | PCOS + Obesity | META B PCOS + PHENOTYPE INFLAMMATION (F-PCOS-1 NOT added) |
| G-3 | HBR + Heat treatment | HBR only if Q3 = Broken/short hair (Q13 alone no longer forces HBR) |
| G-4 | Genetics + Female ≥ 30 | META B-led only; FPHL suppressed entirely (even if Q2/Q3 fire it) |

## 5. Kit-Scorer Rules (executable rule files)
`src/packages/ai-engine/kit-scorer/rules/`:

| File | Purpose |
|---|---|
| `activeSheddingRule.ts` | TE GOLD gating for active shedding |
| `giGoldFinalGuardRule.ts` | Enforces GI GOLD trigger lock (GERD/IBS/Acid reflux/Crohn only) |
| `giGoldSupersedesTeGoldRule.ts` | Gut-axis upstream — GI GOLD wins Phase 1 |
| `glp1PrecedenceRule.ts` | GLP-1 (weight-loss drug) precedence |
| `greyGoalRule.ts` | EARLY_GREY_LOCK / GREY_CO_CONDITION |
| `ironUpInjectionRule.ts` | IRON UP injection (deficiency → Phase 1) |
| `lactihealthInjectionRule.ts` | LACTIHEALTH for lactation cases |
| `menopauseContinuumInjectionRule.ts` | Peri / Meno / Post-meno continuum (non-negotiable) |
| `metabolicModifierRule.ts` | Metabolic kit modifier for sedentary/obesity/diet |
| `pcosMetaBVariantRule.ts` | PCOS → META B PCOS variant |
| `pcosStackRule.ts` | PCOS kit stacking logic |
| `periMenopauseSupersedesTeGoldRule.ts` | Peri replaces TE GOLD |
| `proImmuneLastRule.ts` | PRO IMMUNE always last in standard sequence |
| `regrowGoalRule.ts` | Regrow-only path suppresses TE GOLD |
| `signalGatedInjectionRule.ts` | Generic signal-gated kit injection |
| `teGoldGatingRule.ts` | TE GOLD gating for non-active-shedding cases |
| `thyroidInjectionRule.ts` | Thyroid kit selection (HYPO / HYPER); PCOS + HYPO → plain META B (2026-06-17 lock) |

## 6. Clinical Engine Rules
`src/packages/ai-engine/clinical-engine/rules/`:
- `absoluteLocks.ts` — protocol locks (e.g., EARLY_GREY)
- `agaRules.ts` — AGA grade routing (G1–G3 vs G4–G5)
- `hormonalRules.ts` — PCOS, thyroid, menopause continuum routing
- `lifestyleRules.ts` — sedentary, smoking, weight-loss
- `metabolicRules.ts` — META B family activation
- `teRules.ts` — Telogen Effluvium routing

## 7. Phase Sequencer
Per `kit-scorer/protocolSequencer.ts` — `PROTOCOL_SEQUENCER` is a `Record<DiagnosisKey, ProtocolEntry>` mapping every diagnosis key to its base phase ordering and clinical rationale. Example entries:

| DiagnosisKey | Phases (in order) |
|---|---|
| TE_STRESS | HAIR FACT TE GOLD → PHENOTYPE INFLAMATION |
| TE_POSTPREG | LACTIHEALTH → HAIR FACT TE GOLD → PRO IMMUNE GOLD |
| AGA_MALE_123 | HAIR FACT TE GOLD → PHENOTYPE INFLAMATION → MPHL → PRO FACT META B → PRO IMMUNE GOLD |
| AGA_MALE_45 | PRO IMMUNE GOLD → MPHL → PHENOTYPE INFLAMATION |
| AGA_FEMALE_123 | HAIR FACT TE GOLD → PHENOTYPE INFLAMATION → FPHL → PRO FACT META B → PRO IMMUNE GOLD |
| AGA_FEMALE_45 | PRO IMMUNE GOLD → FPHL → PHENOTYPE INFLAMATION |
| PCOS_ONLY | PRO FACT META B PCOS → PHENOTYPE INFLAMATION → HAIR FACT TE GOLD |
| PCOS_OBESITY | PRO FACT META B PCOS → PHENOTYPE INFLAMATION (G-2: F-PCOS-1 NOT added) |
| THYROID_HYPO | PRO FACT META B HYPOTHYROID → PHENOTYPE INFLAMATION → HAIR FACT TE GOLD (override: + obesity → plain META B) |
| THYROID_HYPER | PRO FACT THYROID CARE → HAIR FACT TE GOLD → PRO IMMUNE GOLD |
| ALOPECIA_AREATA | HAIR FACT ALOPECIA AREATA → PRO FACT META B → PHENOTYPE INFLAMATION → PRO IMMUNE GOLD |
| PERI_MENOPAUSE | HAIR FACT PERI MENOPAUSE → FPHL → HAIR FACT TE GOLD → PRO IMMUNE GOLD |
| MENOPAUSE | PRO FACT META B MENOPAUSE → FPHL → HAIR FACT TE GOLD |

## 8. Root-Cause Phase-1 Precedence (when multiple kits qualify for Phase 1)
Top-down, first match wins (CKM ref §5):
1. Pregnancy (HEALTHY-9) — exclusive
2. Gut-axis kit (GI GOLD) — if Q10 fires
3. Iron repletion (IRON UP GOLD) — if Q11 = iron deficiency
4. Acute lactation / weight-loss shield (LACTIHEALTH / RAPID WEIGHT LOSS SHIELD)
5. Condition-specific (AA / TTM / NIGHT SHIFT / FREQUENT FLYERS / FH WELL 3)
6. Hormonal kit (F-PCOS-1 / META B PCOS / META B HYPO / THYROID CARE / PERI / META B POSTMENO)
7. Metabolic kit (PRO FACT META B)
8. Shaft-repair (HBR) — if Q3 = broken/short
9. PHENOTYPE INFLAMMATION — terrain clearer
10. HAIR FACT TE GOLD — only if no stronger root cause; otherwise Phase 2

## 9. Multi-Factorial Universal Rule
If 3+ root causes fire across Q4/Q7/Q8/Q9, **PHENOTYPE INFLAMMATION is forced to Phase 1** unless a higher-precedence root cause (GI, Iron, Pregnancy) is also active. Cited in CKM ref §5 ("Universal rule").

## 10. Pseudocode (canonical implementation contract)
From CKM ref §7:
```
selectKitsAndSequence(answers, gender, age) {
  candidates = []
  for each (q, a) in answers:
    candidates += RULES[q][a]                    // §1 tables — per-answer kit list

  candidates = applyHardRules(candidates, gender, age, answers)  // HR-1..HR-6
  candidates = applyGovernance(candidates, answers)              // G-1..G-4
  candidates = dedupe(candidates)

  return assignPhases(candidates, answers)        // §5 table + branching
}
```
Every rule fired carries its source `(question, answer)` tuple → required for the V3 report "evidence we used" lines.

## 11. Exclusions & Fallbacks
- **Eligibility gate (Kit-level):** `src/packages/ai-engine/clinical-engine/contraindications/checkTherapyEligibility.ts` + `therapy_blocks.json` — therapy/ingredient contraindications.
- **Refuse-to-fabricate fallback:** If composer cannot find a candidate paragraph satisfying gender/severity/driver filters, it emits an honest minimal section ("Based on your current data, your primary driver is X; additional findings will refine this section as more data is gathered") — `CONSULTATION_EXPERIENCE_ARCHITECTURE.md` §6.
- **Hard contraindications** route through `validateContraindications.ts`.

## 12. Decision Tree (compressed)
```
IF goal == Early Greying SOLE          → EARLY_GREY (lock)
ELIF Q9 == Pregnancy                   → HEALTHY-9 (lock, HR-2)
ELIF Q9 == Post-delivery feeding       → LACTIHEALTH + META B + PRO IMMUNE
ELIF Q4 contains Genetics:
   IF Male                             → MPHL + PRO IMMUNE (G1–G3) | PRO IMMUNE → MPHL → PHENOTYPE (G4–G5)
   ELIF Female age < 30                → TE GOLD + PRO IMMUNE (FPHL gated, FPHL_AGE_GATE)
   ELIF Female age >= 30               → META B + PRO IMMUNE (FPHL suppressed entirely — G-4)
ELIF Q9 == PCOS only                   → META B PCOS + PHENOTYPE + TE GOLD
ELIF Q9 == PCOS + Obesity              → META B PCOS + PHENOTYPE (F-PCOS-1 NOT added — G-2)
ELIF Q9 == Peri-menopause              → PERI MENOPAUSE + FPHL + (no TE GOLD)
ELIF Q9 == Menopause                   → META B MENOPAUSE + FPHL
ELIF Q11 == Iron deficiency            → IRON UP GOLD (Phase 1) + ...
ELIF Q10 in {GERD, IBS, Acid reflux, Crohn} → GI GOLD Phase 1 + …
ELIF Q3 == Bald patches                → ALOPECIA AREATA + META B + PHENOTYPE + PRO IMMUNE
ELIF Q3 == Broken/short                → HBR (+ HBR also if Q13 heat — G-3)
ELSE                                    → TE-led ladder per Q1/Q2/Q4 (Stress/Nutrition/Illness)

THEN apply HR-1 (veg swap), HR-5 (age severity), HR-6 (dedup)
THEN assign phases via PROTOCOL_SEQUENCER + root-cause precedence + multifactorial universal
```

## 13. Determinism Guarantees (per RDE)
- Same ledger state + same engine versions → byte-identical recommendation output.
- Every recommendation carries: candidate id, ranking position, upstream cause chain, exclusion rationale for non-selected candidates, confidence tier (never raw numbers in patient view), audit chain id.
- The RDE asserts **Kit Eligibility classes**, not Kit ids; final kit identity resolution belongs to Kit Knowledge layer (`resolveKit.ts`).
