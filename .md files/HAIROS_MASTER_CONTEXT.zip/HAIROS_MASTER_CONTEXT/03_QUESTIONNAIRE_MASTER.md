# 03 — Questionnaire Master

## Executive Summary
The Dr.FACT clinical questionnaire is a single JSON schema of 6 sections and 21 questions, extracted from the legacy `DrFACT_revamp_v44.html` (2026-05-15) into `src/packages/ai-engine/questionnaire-engine/schema/questionnaire.schema.json`. Every option carries `triggers`, `clinicalTags`, `followUpQuestions`, and may carry `visibleOnlyIf`, `mutuallyExclusive`, `image`, or `illustration` metadata. Each question may carry `scoringSignals` (rules feeding the clinical brain), `clinicalMappings` (condition implications), `dynamicFilterRule` (e.g., hide options for age band), `mutualExclusivityRules`, `skipLogic`, and a `sourceCodeReference` back to the original HTML line. The schema is the single source of truth; legacy `apps/patient-portal/src/config/questionnaire/questions.ts` is an explicit `[]` stub. Driver/cause/kit mappings are exhaustively listed in [`../CONDITION_KIT_MAPPING_REFERENCE.md`](../CONDITION_KIT_MAPPING_REFERENCE.md) — this file gives the navigable index and per-question structural summary; for every option's kit consequence consult that reference.

## 1. Source of Truth
- Schema: `src/packages/ai-engine/questionnaire-engine/schema/questionnaire.schema.json` (3,238 lines)
- Typed wrapper: `src/packages/ai-engine/questionnaire-engine/protocol/masterProtocol.ts` (re-exports as `MasterProtocol`)
- Runtime adapter (schema → frontend `Question[]`): `apps/patient-portal/src/runtime/protocolAdapter.ts`
- Runtime loader: `apps/patient-portal/src/runtime/protocolLoader.ts`
- Visibility / skip / option-filter / step / progress engines: `apps/patient-portal/src/runtime/{visibility,skip,optionFilter,step,progress}Engine.ts`
- Signal extractor: `apps/patient-portal/src/runtime/signalExtractor.ts`
- Branching contract: `docs/BRANCHING_ENGINE_SPEC.md`
- Runtime architecture: `docs/PROTOCOL_RUNTIME_ARCHITECTURE.md`

## 2. Section Index

| Section ID | Title | Description | Questions |
|---|---|---|---|
| S1_PATIENT_IDENTITY | Patient Identity | Core demographic and goal capture | name, age, goal, sex |
| S2_HAIR_LOSS_ASSESSMENT | Hair Loss Assessment | Duration / volume / morphology | duration, count, hairtype |
| S3_SCALP_CONDITION | Scalp Condition | Scalp state | scalp |
| S4_MEDICAL_HISTORY | Medical History & Causes | Suspected cause + systemic flags | cause, immunity, lifestyle, thyroid, medical, medical_detail, hormonal |
| S5_NUTRITION_AND_DIET | Nutrition, Diet & Treatments | Gut, deficiencies, diet, cosmetic exposure | gut, deficiency, diet, treatment |
| S6_GRADE_AND_ADDITIONAL | Hair Loss Grade & Additional Notes | Norwood/Ludwig grade + free notes | grade, extra |

Total: **21 questions** across 6 sections.

## 3. Question Index (with semantic role)

| ID | Type | Label | Required | Drives… |
|---|---|---|---|---|
| name | text | "What is your full name?" | yes | Patient identity only |
| age | number (10–150) | "How old are you?" | yes | AGA_AGE_MODIFIER (+5 if >30), AGA_GRADE45_LOCK (>=20 + G4/5), FPHL_AGE_GATE (F<30 → TE+PRO IMMUNE), GOAL_FILTER (>=30 hides Early Greying) |
| goal | multi_select | "What are your major concerns?" | yes | EARLY_GREY_LOCK, GREY_CO_CONDITION, REGROW path (suppresses TE GOLD), active-shedding diagnostic flow. Mutex on active-shedding ↔ regrow-only |
| sex | single_select | "What is your gender?" | yes | Gender filter on all kits (`HR-3`, `HR-4`); enables Norwood (M) / Ludwig (F) grade options |
| duration | single_select | "How long have you been experiencing hair loss?" | conditional (active shedding) | TE → TE+INFLAM → TE+INFLAM+PRO IMMUNE → PRO IMMUNE+INFLAM ladder (per Q1 table in CKM ref) |
| count | single_select | "How much hair do you lose per day?" | conditional | TE GOLD ladder + pattern-baldness routing |
| hairtype | single_select | "What type of hair fall are you seeing?" | conditional | TE / HBR / AA / pattern routing |
| scalp | multi_select | "What's your scalp like right now?" | yes | Seborrheic, inflammation, HBR (dry), Phenotype Inflammation; pairwise mutex on oily ↔ dry |
| cause | multi_select | "What do you think is causing your hair loss?" | yes | The richest router: Stress/Postpartum/Nutrition/Genetics/Medication/Illness/HardWater/TTM all map to specific kits |
| immunity | multi_select | "Do you experience any of these?" | conditional | Immune dysregulation, allergies, AA, scarring alopecia, etc. → PRO IMMUNE / PHENOTYPE / GI / META B routes |
| lifestyle | multi_select | "Which of these apply to your lifestyle?" | yes | Smoking/alcohol → OXIDATIVE STRESS; Sedentary/Obesity → META B; Sleep → NIGHT SHIFT; Weight loss → RAPID WEIGHT LOSS SHIELD; Frequent flying → FREQUENT FLYERS |
| thyroid | single_select | Thyroid status | conditional (Female / suggestive) | HYPO → META B HYPOTHYROID; HYPER → THYROID CARE |
| medical | multi_select | Chronic / autoimmune conditions | yes | META B + PRO IMMUNE + PHENOTYPE INFLAMMATION |
| medical_detail | text/multi | Free-text/follow-up on specific medical conditions | conditional | Narrative enrichment |
| hormonal | multi_select | Hormonal status (Female-gated) | conditional | PCOS/Endometriosis/Pregnancy/Post-delivery/Peri/Menopausal/HRT routes |
| gut | multi_select | Gut symptoms | yes | GERD/IBS/Acid reflux/Crohn → **PRO FACT GI GOLD Phase 1** (per `MEMORY.md` GI GOLD trigger rule); bloating/constipation → GI HEALTH only |
| deficiency | multi_select | Known deficiencies | yes | Iron deficiency → IRON UP GOLD Phase 1 |
| diet | multi_select | Dietary pattern | yes | Veg/Vegan/Jain → globally swap kits to VEG variants (`HR-1`) |
| treatment | multi_select | Cosmetic / chemical treatments | yes | Heat/chemical → HBR **only if Q3 = broken/short** (governance G-3) |
| grade | image_select | Norwood (M) / Ludwig (F) grade | conditional | G4–G5 → advanced AGA branch (`AGA_*_45`) — PRO IMMUNE Phase 1 |
| extra | text | Free-text additional notes | optional | Narrative input |

## 4. Per-Option Metadata Shape
Each option in the schema can carry:
```json
{
  "label": "...",
  "value": "...",
  "icon": "🛑",
  "triggers": ["activates duration/count/hairtype"],
  "clinicalTags": ["active_shedding", "telogen_effluvium_possible"],
  "followUpQuestions": ["duration", "count", "hairtype"],
  "visibleOnlyIf": { "dependsOn": "sex", "operator": "==", "value": "Female" },
  "mutuallyExclusive": "scalp_oily_vs_dry",
  "image":        { "url": "...", "alt": "..." },
  "illustration": { "url": "...", "alt": "..." }
}
```
(Definitions: `src/packages/ai-engine/questionnaire-engine/protocol/masterProtocol.ts` lines 19–38.)

## 5. Per-Question Metadata Shape
```json
{
  "id": "goal",
  "type": "multi_select",
  "label": "...", "subtitle": null,
  "required": true, "multiSelect": true,
  "options": [...],
  "visibilityRules": [{ "dependsOn": "age", "operator": ">=", "value": "30" }],
  "skipLogic":       [{ "if": {...}, "thenSkipTo": "scalp", "description": "..." }],
  "dependencies":    ["age"],
  "dynamicFilterRule":     { "condition": "parseInt(ans.age) >= 30", "filteredOptions": [...] },
  "mutualExclusivityRules":{ "rules": [{ "selecting": "...", "deselects": "..." }] },
  "runtimeModification":   { "removedOption": "...", "updatedHint": "..." },
  "validation":      { "min": 10, "max": 150, "placeholder": "...", "minLength": 2, "hint": "..." },
  "scoringSignals":  [{ "signal": "AGA_AGE_MODIFIER", "rule": "age > 30 adds +5 to AGA score" }],
  "clinicalMappings":[{ "condition": "Age > 30", "implication": "Elevated MPHL/FPHL risk" }],
  "uiMetadata":      { "layout": "image_grid", "voiceEnabled": true, "imageSelect": true },
  "sourceCodeReference": "STEPS[2] line 3015"
}
```

## 6. Scoring Signal Catalog (examples from schema)
Defined inline per question via `scoringSignals[]`. Sample (from `age` and `goal`):

| Signal | Rule | Source |
|---|---|---|
| AGA_AGE_MODIFIER | age > 30 adds +5 to AGA score | `matchProtocol` line 4389 |
| AGA_GRADE45_LOCK | age >= 20 AND grade 4/5 → forces `AGA_MALE_45` / `AGA_FEMALE_45` | `matchProtocol` line 4250–4253 |
| FPHL_AGE_GATE | Female under 30 with genetics → TE + PRO IMMUNE (not FPHL) | `getFunnelKits` line 4696–4699 |
| GOAL_FILTER | age >= 30 → filter goal options to only first 2 | `STEPS[2]._filterOpts` line 3015–3019 |
| EARLY_GREY_LOCK | goal sole-selects Early Greying → absolute lock to `EARLY_GREY` protocol | inline |
| GREY_CO_CONDITION | goal includes Early Greying + hair fall/regrow → append EARLY GREYING CARE kit | inline |

The complete set of signals is enumerated in `HAIROS_SIGNAL_REGISTRY_V1.md`.

## 7. Driver / Cause Mapping
Every option's downstream consequence on diagnosis routing and kit selection is enumerated in [`../CONDITION_KIT_MAPPING_REFERENCE.md`](../CONDITION_KIT_MAPPING_REFERENCE.md) §1 (Q1–Q13 decision rules). The 10 root causes are in the Cause Registry: `src/packages/ai-engine/cause-registry/catalog.ts` (Bayesian softmax over 10 causes; multifactorial requires `compositeRule` — see `MEMORY.md` `project_sprint1_week3_causes`).

## 8. Validated Governance Rules (from MEMORY)
Locked questionnaire / kit-injection feedback (carry-forward, must not be re-litigated):
- **GI GOLD trigger:** PRO FACT GI GOLD only for GERD / IBS / Acid reflux / Crohn, Phase 1 only. Never for Bloating, Constipation, Indigestion. (`feedback_gi_gold_trigger.md`)
- **F-PCOS -1 retired**; HBR standalone-only; menopause continuum non-negotiable.
- **Thyroid rule (2026-06-17):** PCOS + Hypo → plain META B (3-axis kit).
- **Heavy bleeding periods** option added (Female 18-50) → IRON UP Phase 1.
- **Pescatarian** option added; **Scarring alopecia + Menopause** removed; "peri" substring collision fixed.
(`feedback_kit_injection_rules.md`, `feedback_questionnaire_changes_2026_06_15.md`)

## 9. Acceptance Behaviors
- Schema is the single source of truth. Frontend MUST NOT hardcode question content.
- Replay deterministic: `runtime/stepResolver.ts` exposes `buildReplayFrames(protocol, fixture)` for QA replay (see `HAIROS_CONSTITUTIONAL_TEST_CORPUS_V1.md`).
- Source-line traceability: every question has a `sourceCodeReference` back to `DrFACT_revamp_v44.html` for audit.

## 10. Gaps
- The schema dates to 2026-05-15. The 2026-06-15 questionnaire changes (Heavy bleeding, Pescatarian, removal of Scarring alopecia/Menopause from inappropriate slots) noted in `MEMORY.md` may not all be reflected in the JSON; verify before using the schema as a current-state oracle. [INFERRED]
