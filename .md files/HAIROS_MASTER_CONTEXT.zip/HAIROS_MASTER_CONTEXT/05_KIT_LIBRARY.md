# 05 — Kit Library

## Executive Summary
HairOS prescribes from a deterministic catalog of ~30 oral kits (Hair Fact + Pro Fact product lines) and ~14 topical products. Each kit has a clinical role (terrain, primary condition, systemic, consolidation), gender / veg gating, and triggers tied directly to questionnaire answers. The canonical kit master + trigger map is [`../CONDITION_KIT_MAPPING_REFERENCE.md`](../CONDITION_KIT_MAPPING_REFERENCE.md) §2; the phase-by-phase intent (Terrain → Primary → Systemic → Consolidate) is §5 of the same doc. Kit clinical narratives (ingredients, mechanisms, "expected response" copy) live in `all-kits-info.txt` (readable) and `All Kits  Info.docx` (binary — cite, do not parse). Topical catalog: `src/packages/ai-engine/clinical-engine/kits/products.json`.

## 1. Kit Master (29 active kits + Early Greying = 30)
Source of truth: [`../CONDITION_KIT_MAPPING_REFERENCE.md`](../CONDITION_KIT_MAPPING_REFERENCE.md) §2. Reproduced for navigability:

| # | Kit | Line | Gender | Veg variant | Primary use |
|---|---|---|---|---|---|
| 1 | HAIR FACT TE GOLD | Hair Fact | Both | Yes → VEG | Telogen Effluvium (non-veg) |
| 2 | HAIR FACT TE GOLD VEG | Hair Fact | Both | — | TE (veg/vegan) |
| 3 | MPHL | Hair Fact | Male | No | Male AGA G1–G5 |
| 4 | FPHL | Hair Fact | Female | No | Female AGA G1–G5 |
| 5 | PHENOTYPE INFLAMMATION | Hair Fact | Both | No | Scalp & systemic inflammation — universal terrain |
| 6 | PRO IMMUNE GOLD | Hair Fact | Both | No | Standard immune modulation |
| 7 | PRO IMMUNE GOLD PLUS | Hair Fact | Both | No | Advanced immune (severe / G4–G5) |
| 8 | PRO IMMUNE VEG | Hair Fact | Both | — | Immune (veg) |
| 9 | HAIR FACT ALOPECIA AREATA | Hair Fact | Both | No | Autoimmune AA |
| 10 | HAIR FACT HBR | Hair Fact | Both | No | Hair shaft breakage |
| 11 | F-PCOS-1 | Hair Fact | Female | Yes → VEG | PCOS / PCOD / PMOS (pure, no obesity) |
| 12 | F-PCOS VEG-1 | Hair Fact | Female | — | PCOS (veg) |
| 13 | HAIR FACT PERI MENOPAUSE | Hair Fact | Female | Yes → VEG | Peri-menopausal |
| 14 | HAIR FACT PERI MENOPAUSE VEG | Hair Fact | Female | — | Peri-menopausal (veg) |
| 15 | HAIR FACT NIGHT SHIFT | Hair Fact | Both | No | Circadian disruption |
| 16 | HAIR FACT FREQUENT FLYERS | Hair Fact | Both | No | Frequent flying / cabin radiation |
| 17 | HAIR FACT TTM (OCD) | Hair Fact | Both | No | Trichotillomania |
| 18 | HEALTHY-9 | Hair Fact | Female | No | Pregnancy support — **only** kit during pregnancy |
| 19 | PRO FACT META B | Pro Fact | Both | No | Metabolic dysfunction / chronic condition |
| 20 | PRO FACT META B PCOS | Pro Fact | Female | No | PCOS + obesity (metabolic PCOS); supersedes F-PCOS-1 |
| 21 | PRO FACT META B HYPOTHYROID | Pro Fact | Female | No | Hypothyroid hair loss |
| 22 | PRO FACT THYROID CARE | Pro Fact | Female | No | Hyperthyroid hair loss |
| 23 | PRO FACT META B POSTMENOPAUSE | Pro Fact | Female | No | Post-menopausal transition |
| 24 | RAPID WEIGHT LOSS SHIELD | Hair Fact | Both | No | Sudden weight-loss / GLP-1 shedding |
| 25 | IRON UP GOLD | Hair Fact | Both | No | Iron deficiency / anaemia (incl. heavy periods, Female 18–50) |
| 26 | LACTIHEALTH | Hair Fact | Female | No | Post-pregnancy / breastfeeding |
| 27 | FH WELL 3 | Hair Fact | Female | No | Endometriosis / hormonal inflammation |
| 28 | OXIDATIVE STRESS | Hair Fact | Both | No | ROS damage / smoking / pollution |
| 29 | PRO FACT GI GOLD | Pro Fact | Both | Yes → VEG | Gut dysbiosis — GERD/IBS/Acid reflux/Crohn (Phase 1 only) |
| 30 | EARLY GREYING CARE / VEG / GOLD | Hair Fact | Both | Yes | Early greying (age < 30) |

## 2. Phase Assignment (intent)
From CKM §5:

| Phase | Months | Therapeutic role | Typical Phase-1 kits |
|---|---|---|---|
| Phase 1 | M1–M2 | Repair cellular **ENVIRONMENT** | META B family, IRON UP GOLD, GI GOLD, LACTIHEALTH, ALOPECIA AREATA, PERI MENOPAUSE, F-PCOS-1, RAPID WEIGHT LOSS SHIELD, NIGHT SHIFT, FREQUENT FLYERS, TTM, HBR, FH WELL 3, HEALTHY-9 (exclusive) |
| Phase 2 | M3–M4 | Target the **PRIMARY** hair condition | TE GOLD, MPHL, FPHL, PHENOTYPE INFLAMMATION (as primary), HBR (as primary) |
| Phase 3 | M5–M6 | Address **systemic / hormonal / metabolic** layer | PRO IMMUNE GOLD, OXIDATIVE STRESS |
| Phase 4 | M7–M8 | **Consolidate** — prevent relapse | PRO IMMUNE GOLD PLUS |

## 3. AGA Grade Branching

| Grade | Phase 1 | Phase 2 | Phase 3 |
|---|---|---|---|
| Male G1–G3 | HAIR FACT TE GOLD | MPHL | PRO IMMUNE GOLD |
| Male G4–G5 | PRO IMMUNE GOLD | MPHL | PHENOTYPE INFLAMMATION |
| Female G1–G3 | HAIR FACT TE GOLD | FPHL | PRO IMMUNE GOLD |
| Female G4–G5 | PRO IMMUNE GOLD | FPHL | PHENOTYPE INFLAMMATION |

## 4. Per-Kit Clinical Narrative
Each kit has a clinical recommendation block in `all-kits-info.txt` containing: Diagnosis Insight, Treatment Objective, Therapeutic Strategy, Formulation Rationale, Expected Clinical Response (Weeks 2–4 / 6–8 / 10–12), Clinical Note, Conclusion.

Example shape (HAIR FACT TE GOLD, `all-kits-info.txt` lines 56–89):
- **Diagnosis Insight:** "Hair shedding pattern consistent with Telogen Effluvium — temporary disruption…"
- **Therapeutic strategy:** Five pathways — Inflammation control · Nutritional repletion · Metabolic optimisation · Hormonal modulation · Stress regulation.
- **Ingredients / Mechanism (excerpt):**
  - Essential Amino Acids (Leucine, Isoleucine, Lysine) → keratin building blocks
  - Vitamin D3 + B6 + Folic Acid → cell turnover, follicular activation
  - Vitamin C → IGF-1 boost (telogen → anagen), iron absorption
  - Curcumin → anti-inflammatory, gut microbiome
  - Kelp Seaweed → iodine/selenium, thyroid-linked metabolism, IGF-1/VEGF
  - Moringa → nutrient absorption, antioxidant; phytosterols reduce DHT
  - Melatonin → cortisol regulation, 5-α-reductase modulation
  - Lactoferrin → ferritin support
  - Probiotics + Bioperine → absorption
  - Ashwagandha → cortisol reduction
- **Expected response:** W2–4 reduction in shedding; W6–8 strength + variability; W10–12 visible regrowth.

For the full ingredient inventory and mechanism dictionary across every kit, see [`../HAIROS_INGREDIENT_INTELLIGENCE_MASTER_V1.md`](../HAIROS_INGREDIENT_INTELLIGENCE_MASTER_V1.md) and `all-kits-info.txt`.

## 5. Ingredient Cross-References
- **Ingredient → mechanism dictionary (code):** `src/packages/ai-engine/report-engine/v3/ingredientMechanisms.ts`
- **Kit brand-name map:** `src/packages/ai-engine/report-engine/v3/kitBrandNames.ts`
- **Barrier → root cause map:** `src/packages/ai-engine/report-engine/v3/barrierMap.ts`
- **Knowledge retrievers:** `src/packages/ai-engine/knowledge-engine/retrievers/`

## 6. Topical Products (separate catalog, 14 SKUs)
Source: `src/packages/ai-engine/clinical-engine/kits/products.json` (extracted from `DrFACT_revamp_v44.html` lines 2037–2103).
Each topical carries `tags`, `scalpMatch` (normal/oily/dry), `gender`, `contraindications`, `hormonalSafe`, `harsh`, `usage`, `note`. Examples:
- Minoxidil 5% — pattern thinning; pregnancy contraindicated; harsh; oily/normal scalp.
- Minoxidil 2% + Finasteride 0.25% Topical — androgen-sensitive thinning; doctor-supervised; pregnancy contraindicated.

Topicals are produced by `src/packages/ai-engine/clinical-engine/buildTopicals.ts`.

## 7. Loaders
- `src/packages/ai-engine/clinical-engine/loaders/loadProducts.ts` — loads `kits/products.json`
- `src/packages/ai-engine/clinical-engine/protocols/global.json` — global protocol defaults

## 8. Driver / Cause → Kit Quick-Index

| Root cause / driver | Primary kits |
|---|---|
| Active shedding (TE) | HAIR FACT TE GOLD (Phase 1 or 2) |
| AGA (male) | MPHL + PRO IMMUNE GOLD (+ META B if metabolic) |
| AGA (female ≥30) | PRO FACT META B (FPHL suppressed by G-4) |
| AGA (female <30 + genetics) | HAIR FACT TE + PRO IMMUNE GOLD |
| PCOS pure | F-PCOS-1 / PRO FACT META B PCOS |
| PCOS + obesity | PRO FACT META B PCOS + PHENOTYPE INFLAMMATION (G-2) |
| PCOS + hypothyroid | PRO FACT META B (3-axis kit, 2026-06-17 lock) |
| Hypothyroid | PRO FACT META B HYPOTHYROID |
| Hyperthyroid | PRO FACT THYROID CARE |
| Pregnancy | HEALTHY-9 (HR-2 lock — only kit) |
| Post-partum breastfeeding | LACTIHEALTH + META B + PRO IMMUNE |
| Peri-menopause | HAIR FACT PERI MENOPAUSE + FPHL |
| Menopause | PRO FACT META B MENOPAUSE + FPHL |
| Iron deficiency / heavy periods | IRON UP GOLD (Phase 1, non-negotiable) |
| GERD / IBS / Acid reflux / Crohn | PRO FACT GI GOLD (Phase 1) + PRO IMMUNE GOLD |
| Bloating / constipation only | PRO FACT GI HEALTH + PRO IMMUNE GOLD (GI GOLD never fires) |
| Alopecia areata | HAIR FACT ALOPECIA AREATA + META B + PHENOTYPE + PRO IMMUNE |
| Trichotillomania | HAIR FACT TTM |
| Hard water / heat damage | HAIR FACT HBR (gated by Q3 = broken/short) |
| Sedentary / obesity / chronic disease | PRO FACT META B |
| Smoking / alcohol / pollution | PHENOTYPE INFLAMMATION + OXIDATIVE STRESS |
| Night shift | HAIR FACT NIGHT SHIFT |
| Frequent flying | HAIR FACT FREQUENT FLYERS |
| Rapid weight loss / GLP-1 | RAPID WEIGHT LOSS SHIELD |
| Endometriosis | FH WELL 3 + PHENOTYPE INFLAMMATION |
| Early greying (<30, sole goal) | EARLY GREYING CARE (lock) |
| Severe G4–G5 consolidation | PRO IMMUNE GOLD PLUS (Phase 4) |

## 9. Source Files (citation only — binary)
- `Kits & Product.xlsx` — kit catalog master
- `All Kits  Info.docx` — kit clinical narratives source
- `DrFACT_Protocol_Sequencer Final.xlsx` — phase sequencer source
- `DrFACT_Condition_Mapping_Latest Final.xlsx` — condition→kit mapping source
- `data/docs/{DrFACT_Condition_Mapping_New.txt, DrFACT_Protocol_Sequencer updated.txt, Phenotype Kits Indications.txt}` — flat exports

## 10. Open Items
- F-AGA vs FPHL naming: updated mapping introduces "F-AGA" for some Menopausal and Female-bodybuilding rows; older rules use FPHL. Same for MPHL → M-AGA. Disambiguation pending (CKM ref §8).
- Kit Master Reference vs Mapping: some legacy names co-exist (e.g., F-PCOS-1 vs PRO FACT META B PCOS) — rollout status flags blank on some kits.
- Early Greying Q-mapped trigger missing in current Sequencer sheet — currently doctor-initiated (CKM ref §8).
